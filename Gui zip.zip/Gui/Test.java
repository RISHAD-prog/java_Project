public class Test 
{
	public static void main(String [] args)
	{
		Project pr = new Project();
		pr.show();
		//pr.setVisible(true);
		
	}
}